<?php

require_once( dirname( __FILE__ ) . '/admin/ajax-backlink.php' );

?>